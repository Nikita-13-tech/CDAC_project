package com.cdac.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cdac.project.model.File;
import com.cdac.project.model.Folder;

@Repository
public interface FolderRepository extends JpaRepository<Folder, Long>{

	// Add custom query methods if needed
	List<Folder> findBySharedWithUsersContains(Long userId);
	
	List<Folder> findByfolderNameContainingIgnoreCase(String query);
	
	public static String findDataById(Long folderId) {
		return null;
	}
}
