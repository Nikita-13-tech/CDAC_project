package com.cdac.project.model;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.*;

@Entity
@Table(name="File")
public class File {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="File_Id")
	private Long fileId;
	
	@Column(name="File_Name",unique = true)
	private String name;
	
	@Column(name="Date_of_Creation")
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate dateofCreation;
	
	@Column(name="File_size")
	private double size;
	
	@Column(name="Last_Modified_Date")
	private LocalDate lastModifiedDate;
	
	@ManyToOne
	@JoinColumn(name="uid")
	private User user;
	
	@ElementCollection
	@CollectionTable(name = "file_shared_users", joinColumns = @JoinColumn(name = "file_id"))
	@Column(name = "user_id")
	private List<Long> sharedWithUsers;

	private String data; // Assuming file data will be stored as a string
	
	@ManyToOne
	@JoinColumn(name="folder_id")
	private Folder folder;
	
	//default Constructor
	public File() {
		
	}

	//paramaterized Constructor
	public File(Long fileId, String name, LocalDate dateofCreation, double size, LocalDate lastModifiedDate, User user,
			List<Long> sharedWithUsers, String data, Folder folder) {
		super();
		this.fileId = fileId;
		this.name = name;
		this.dateofCreation = dateofCreation;
		this.size = size;
		this.lastModifiedDate = lastModifiedDate;
		this.user = user;
		this.sharedWithUsers = sharedWithUsers;
		this.data = data;
		this.folder = folder;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDateofCreation() {
		return dateofCreation;
	}

	public void setDateofCreation(LocalDate dateofCreation) {
		this.dateofCreation = dateofCreation;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public LocalDate getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(LocalDate lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Long> getSharedWithUsers() {
		return sharedWithUsers;
	}

	public void setSharedWithUsers(List<Long> sharedWithUsers) {
		this.sharedWithUsers = sharedWithUsers;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Folder getFolder() {
		return folder;
	}

	public void setFolder(Folder folder) {
		this.folder = folder;
	}

	
	
	
	
}
