package com.cdac.project.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.project.model.File;
import com.cdac.project.model.Folder;
import com.cdac.project.service.FolderService;

@RestController
@RequestMapping("/api/folders")
public class FolderController {

	@Autowired
	private FolderService fdservice;
	
	@GetMapping("/")  
	public ResponseEntity<List<Folder>> getAllFolders() {
        List<Folder> folders = fdservice.FindAllFolder();
        return ResponseEntity.ok().body(folders);
    }
																/*
															     * public List<Folder> getAllFolders() {
															     * return fdservice.FindAllFolder();
															    	}
															     */				
      
	@PostMapping("/")
	public ResponseEntity<?> createFolder(@RequestBody String folderName) {
	     fdservice.createFolder(folderName);
	     return ResponseEntity.status(HttpStatus.CREATED).build();
	}
															    /*	public Folder createFolder(@RequestBody Folder folder) {
															     * 	return fdservice.saveFolder(folder);
															    	}
															     */
	     
	@GetMapping("/{folderId}")
    public ResponseEntity<Optional<Folder>> getFolderById(@PathVariable Long folderId) {
        Optional<Folder> folder = fdservice.FindFolderById(folderId);
        return ResponseEntity.ok().body(folder);
    }
																/*
																 *  public Optional<Folder> getFolderById(@PathVariable Long id) {
															        return fdservice.FindFolderById(id);
															    	}
																 */
    
      
    @DeleteMapping("/{folderId}")
    public ResponseEntity<?> deleteFolder(@PathVariable Long folderId) {
        fdservice.deleteFolder(folderId);
        return ResponseEntity.ok().build();
    }
															    /*public void deleteFolder(@PathVariable Long id) {
															        fdservice.deleteFolderById(id);
															    	}
															     */
    

    @GetMapping("/{folderId}/files")
    public ResponseEntity<List<File>> getFilesInFolder(@PathVariable Long folderId) {
        List<File> files = fdservice.getFilesInFolder(folderId);
        return ResponseEntity.ok().body(files);
    }

    @PutMapping("/{fileId}/move/{targetFolderId}")
    public ResponseEntity<?> moveFileToFolder(@PathVariable Long fileId, @PathVariable Long targetFolderId) {
        fdservice.moveFileToFolder(fileId, targetFolderId);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/{folderId}/move/{targetParentFolderId}")
    public ResponseEntity<?> moveFolderToFolder(@PathVariable Long folderId, @PathVariable Long targetParentFolderId) {
        fdservice.moveFolderToFolder(folderId, targetParentFolderId);
        return ResponseEntity.ok().build();
    }
    
    /*
     *review Required not confirm with all types of names of folders
     *apply to find all types of regular expression 
     *add tokenizer concept to specify each different type of file types with Extension
     */
    //<--------------------------------------Search folders---------------------------------------------->
    @SuppressWarnings("unchecked")
	
    @GetMapping("/search")
    public ResponseEntity<List<File>> searchFolder(@RequestParam String query) {
        List<Folder> searchResults = fdservice.searchFolders(query);
        // Assuming searchResults is sorted, you can perform binary search
        int index = binarySearch(searchResults, query);
        if (index >= 0) {
            // Found the folder matching the query
            List<File> result = new ArrayList<>();
            result.addAll((Collection<? extends File>) searchResults.get(index));
            return ResponseEntity.ok(result);
        } else {
            // Folder not found
            return ResponseEntity.ok(Collections.emptyList());
        }
    }

    private int binarySearch(List<Folder> searchResults, String query) {
        int low = 0;
        int high = searchResults.size() - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            int cmp = searchResults.get(mid).getFolderName().compareTo(query);
            if (cmp == 0) {
                return mid; // Found the file
            } else if (cmp < 0) {
                low = mid + 1; // Search in the right half
            } else {
                high = mid - 1; // Search in the left half
            }
        }
        return -1; // File not found
    }
 
}
