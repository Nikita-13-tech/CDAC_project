package com.cdac.project.model;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

import jakarta.persistence.*;


@Entity
@Table(name="User")
public class User {

	    @Id   // Primary key /unique
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name="uid")
	    private Long id;
	    
	    @Column(unique=true)
	    private String username;
	    
	    @Column(unique=true)
	    private String email;
	    
	    @Column(name="first_name")
	    private String fname;
	    
	    @Column(name="last_name")
	    private String lname;
	    
	    @Column(name="phone",unique=true)
	    private String phoneno;
	    
	    private String password;
	    
	    /* Model 1-* Mapping b/w Users & Files*/
	    @OneToMany(mappedBy ="user", cascade = CascadeType.ALL)
	    private List<File> files;  
	    
	    /* Model 1-* Mapping b/w Users & Folders*/
	    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	    private List<Folder> folders;

	    //default Constructor
	    public User() {}
	    
	    //paramaterized Constructor
		public User(Long id, String username, String email, String fname, String lname, String phoneno, String password,
				List<File> files, List<Folder> folders) {
			super();
			this.id = id;
			this.username = username;
			this.email = email;
			this.fname = fname;
			this.lname = lname;
			this.phoneno = phoneno;
			this.password = password;
			this.files = files;
			this.folders = folders;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getFname() {
			return fname;
		}

		public void setFname(String fname) {
			this.fname = fname;
		}

		public String getLname() {
			return lname;
		}

		public void setLname(String lname) {
			this.lname = lname;
		}

		public String getPhoneno() {
			return phoneno;
		}

		public void setPhoneno(String phoneno) {
			this.phoneno = phoneno;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			Base64.Encoder encoder = Base64.getEncoder();  
	        String normalString = password;
	        String encodedString = encoder.encodeToString(   // encrypt password in database field
	        normalString.getBytes(StandardCharsets.UTF_8) );
	        this.password = encodedString;
		}

		public List<File> getFiles() {
			return files;
		}

		public void setFiles(List<File> files) {
			this.files = files;
		}

		public List<Folder> getFolders() {
			return folders;
		}

		public void setFolders(List<Folder> folders) {
			this.folders = folders;
		}
	
}
