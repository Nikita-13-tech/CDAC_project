package com.cdac.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.project.exception.ResourceNotFoundException;
import com.cdac.project.model.User;
import com.cdac.project.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService uservice;
	
	@PostMapping("/register")
	public ResponseEntity<String> createUser(@Validated @RequestBody User user) {
		try {
		
				
		User registeredUser = uservice.registerUser(user);
	        if (registeredUser!= null) {
	            return ResponseEntity.ok("Registration successful");
	        } else {
	            return ResponseEntity.badRequest().body("Registration failed");
	        }
		}
		catch(Exception e) {
			
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("An Error Ocurred: "+e.getMessage());
			
		}
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<Boolean> loginUser(@Validated @RequestBody User user) throws ResourceNotFoundException
	{
		Boolean isAuthenticated = false;
		String email=user.getEmail();
		String password=user.getPassword();
	
		User d = uservice.loginUser(email).orElseThrow(() ->
		new ResourceNotFoundException("User not found for this email :: " + email));
		
		if(email.equals(d.getEmail()) && password.equals(d.getPassword()))
		{
			isAuthenticated = true;

		}
		return ResponseEntity.ok(isAuthenticated);
	}		
}
