package com.cdac.project.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cdac.project.model.File;
import com.cdac.project.model.Folder;
import com.cdac.project.repository.FileRepository;
import com.cdac.project.repository.FolderRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class FolderService {

	@Autowired
	private FolderRepository fdrepo;
	private FileRepository frepo;
	private EncryptionService encservice;
	
	public Folder saveFolder(Folder fd) {
		return fdrepo.save(fd);
	}
	
	public List<Folder> FindAllFolder(){
		return fdrepo.findAll();
	}
	
	public Optional<Folder> FindFolderById(Long folderId) {
		return fdrepo.findById(folderId);
	}
	
	public void deleteFolderById(Long folderId) {
		fdrepo.deleteById(folderId);
	}
	
	
	
	public void createFolder(String folderName) {
	     Folder folder = new Folder();
	     folder.setFolderName(folderName);
	     fdrepo.save(folder);
	}

	public List<Folder> getAllFolders() {
        return fdrepo.findAll();
    }

    public Folder getFolderById(Long folderId) {
        return fdrepo.findById(folderId)
                .orElseThrow(() -> new RuntimeException("Folder not found with ID: " + folderId));
    }

    public List<File> getFilesInFolder(Long folderId) {
        Folder folder = fdrepo.findById(folderId)
                .orElseThrow(() -> new RuntimeException("Folder not found with ID: " + folderId));
        return folder.getFiles();
    }

    public void moveFileToFolder(Long fileId, Long targetFolderId) {
        File file = frepo.findById(fileId)
                .orElseThrow(() -> new RuntimeException("File not found with ID: " + fileId));
        Folder targetFolder = fdrepo.findById(targetFolderId)
                .orElseThrow(() -> new RuntimeException("Folder not found with ID: " + targetFolderId));
        file.setFolder(targetFolder);
        frepo.save(file);
    }

    public void moveFolderToFolder(Long folderId, Long targetParentFolderId) {
        Folder folder = fdrepo.findById(folderId)
                .orElseThrow(() -> new RuntimeException("Folder not found with ID: " + folderId));
        Folder targetParentFolder = fdrepo.findById(targetParentFolderId)
                .orElseThrow(() -> new RuntimeException("Target parent folder not found with ID: " + targetParentFolderId));
        folder.setParentFolder(targetParentFolder);
        fdrepo.save(folder);
    }

    public void deleteFolder(Long folderId) {
        Folder folder = fdrepo.findById(folderId)
                .orElseThrow(() -> new RuntimeException("Folder not found with ID: " + folderId));
        fdrepo.delete(folder);
    }


    
    
    //required review code--------------------------after this---->
    
    
    //<---------------upload file method implementaion ------------->
	// Define the directory where you want to store uploaded files
    
    private static final String UPLOAD_DIR = "/path/to/your/upload/directory/";//make changes 

    public void uploadFolder(MultipartFile file) throws IOException {
        // Extract the filename
        String fileName = file.getOriginalFilename();

        // Define the path where the folder will be stored
        Path folderPath = Paths.get(UPLOAD_DIR + fileName);

        // Save the folder to the specified location
        Files.write(folderPath, file.getBytes());

        // Convert byte[] to Base64 encoded string
        String base64Data = Base64.getEncoder().encodeToString(file.getBytes());

        // Encrypt the Base64 encoded string
        String encryptedData = encservice.encrypt(base64Data);

        // Save encrypted folder data to the database
        Folder newFolder = new Folder();
        newFolder.setFolderName(fileName);
        newFolder.setData(encryptedData);
        fdrepo.save(newFolder);
    }

    public String downloadFolder(Long folderId) {
        String folderData = FolderRepository.findDataById(folderId);
        if (folderData != null) {
            // Decrypt folder data before returning
            return encservice.decrypt(folderData);
        }
        return null;
    }

    public void shareFolder(Long folderId, Long userId) {
        // Retrieve the folder by its ID
        Optional<Folder> optionalFolder = fdrepo.findById(folderId);
        if (optionalFolder.isPresent()) {
            Folder folder = optionalFolder.get();
            // Add logic to share the folder with the user identified by userId
            // For example, you might update the folder's shared With Users list and save the changes
            folder.getSharedWithUsers().add(userId);
            fdrepo.save(folder);
        } else {
            throw new RuntimeException("Folder not found with ID: " + folderId);
        }
    }

    public List<Folder> getSharedFolders(Long userId) {
        // Implement logic to retrieve folders shared with the user identified by userId
        // For example, you might query the database to find folders where userId is included in the sharedWithUsers list
        // Here, we assume there's a method in your repository for this purpose
        return fdrepo.findBySharedWithUsersContains(userId);
    }

    public List<Folder> searchFolders(String query) {
        // Delegate the search operation to the repository method
        return fdrepo.findByfolderNameContainingIgnoreCase(query);
    }
}
