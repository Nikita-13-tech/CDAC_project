package com.cdac.project.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.cdac.project.model.File;
import com.cdac.project.repository.FileRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class FileService {

	@Autowired
	private FileRepository frepo;
	
	@Autowired
	private EncryptionService encservice;
	
	public File saveFile(File f) {
		return frepo.save(f);
	}
	
	public List<File> findAllFile(){
		return frepo.findAll();
	}
	
	public Optional<File> findFileById(Long fileId){
		return frepo.findById(fileId);
	}
	
	public void deleteFileById(Long fileId) {
		frepo.deleteById(fileId);
	}

	//<---------------upload file method implementaion ------------->
	// Define the directory where you want to store uploaded files
    private static final String UPLOAD_DIR = "/path/to/your/upload/directory/";//(still not updated the path or directory) 

    public void uploadFile(MultipartFile file) throws IOException {
    	// Extract the filename
        String fileName = file.getOriginalFilename();

        // Define the path where the file will be stored
        Path filePath = Paths.get(UPLOAD_DIR + fileName);

        // Save the file to the specified location
        Files.write(filePath, file.getBytes());

        // Convert byte[] to Base64 encoded string
        String base64Data = Base64.getEncoder().encodeToString(file.getBytes());

        // Encrypt the Base64 encoded string
        String encryptedData = encservice.encrypt(base64Data);
        
        // Save encrypted file data to the database
        File newFile = new File();
        newFile.setName(fileName);
        newFile.setData(encryptedData);
        frepo.save(newFile);
    }

/*public String downloadFile(Long fileId) {
        File file;
		try {
			file = FileRepository.findById(fileId).orElse(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
        if (file != null) {
            return encservice.decrypt(file.getData());// Decrypt file data before returning
        }
        return null;
    }
 *
 */
    public String downloadFile(Long fileId) {
    	 String fileData = FileRepository.findDataById(fileId);
         if (fileData != null) {
             // Decrypt file data before returning
             return encservice.decrypt(fileData);
         }
         return null;
     }
    
    
    public void shareFile(Long fileId, Long userId) {
        // Retrieve the file by its ID
        Optional<File> optionalFile = frepo.findById(fileId);
        if (optionalFile.isPresent()) {
            File file = optionalFile.get();
            // Add logic to share the file with the user identified by userId
            // For example, you might update the file's shared With Users list and save the changes
            file.getSharedWithUsers().add(userId);
            frepo.save(file);
        } else {
            throw new RuntimeException("File not found with ID: " + fileId);
        }
    }

    public List<File> getSharedFiles(Long userId) {
        // Implement logic to retrieve files shared with the user identified by userId
        // For example, you might query the database to find files where userId is
        // included in the sharedWithUsers list
        // Here, we assume there's a method in your repository for this purpose
        return frepo.findBySharedWithUsersContains(userId);
    }
	
    
    public List<File> searchFiles(String query) {
        // Delegate the search operation to the repository method
        return frepo.findByNameContainingIgnoreCase(query);
    }

	
}
