package com.cdac.project.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.project.model.User;
import com.cdac.project.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository urepo;
	
	public  User registerUser(User u) {
		return urepo.save(u);
	}
	
	/*
	Optional is a container object used to contain not-null objects 
	Optional object is used to represent null with absent value. 
	This class has various utility methods to facilitate code to handle values as ‘available’ or ‘not available’ instead of checking null values. */

	public Optional<User> loginUser(String email) {
		return urepo.findByEmail(email); // Invoke Custom method
	}

}
