package com.cdac.project.model;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="Folder")
public class Folder {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long folderId;
	    
	    @Column(name="Folder_Name")
	    private String folderName;
	    
	    @Column(name="Date_of_Creation")
	    @JsonFormat(pattern="yyyy-MM-dd")
	    private LocalDate dateofCreation;
	    
	    @Column(name="Folder_Size")
	    private float size;
	    
	    @Column(name="Last_Modified_Date")
	    @JsonFormat(pattern="yyyy-MM-dd")
	    private LocalDate lastModifiedDate;
	    
	    @ManyToOne
	    @JoinColumn(name="uid")
	    private User user;

	    @ManyToOne
	    @JoinColumn(name="parent_folder_id")
	    private Folder parentFolder;
	    
	    @OneToMany(mappedBy = "parentFolder", cascade = CascadeType.ALL)
	    private List<Folder> subFolders;
	    
	    @ElementCollection
	    @CollectionTable(name = "folder_shared_users", joinColumns = @JoinColumn(name = "folder_id"))
	    @Column(name = "user_id")
	    private List<Long> sharedWithUsers;

	    private String data;

	    @OneToMany(mappedBy = "folder")
	    private List<File> files;
	    
	    // Default Constructor
	    public Folder() {}
	    
	    // Parametrized Constructor
	    public Folder(Long folderId, String folderName, LocalDate dateofCreation, float size,
				LocalDate lastModifiedDate, User user, Folder parentFolder, List<Folder> subFolders,
				List<Long> sharedWithUsers, String data, List<File> files) {
			super();
			this.folderId = folderId;
			this.folderName = folderName;
			this.dateofCreation = dateofCreation;
			this.size = size;
			this.lastModifiedDate = lastModifiedDate;
			this.user = user;
			this.parentFolder = parentFolder;
			this.subFolders = subFolders;
			this.sharedWithUsers = sharedWithUsers;
			this.data = data;
			this.files = files;
		}

		// Getters and Setters   
		public Long getFolderId() {
			return folderId;
		}

		public void setFolderId(Long folderId) {
			this.folderId = folderId;
		}

		public String getFolderName() {
			return folderName;
		}

		public void setFolderName(String folderName) {
			this.folderName = folderName;
		}

		public LocalDate getDateofCreation() {
			return dateofCreation;
		}

		public void setDateofCreation(LocalDate dateofCreation) {
			this.dateofCreation = dateofCreation;
		}

		public float getSize() {
			return size;
		}

		public void setSize(float size) {
			this.size = size;
		}

		public LocalDate getLastModifiedDate() {
			return lastModifiedDate;
		}

		public void setLastModifiedDate(LocalDate lastModifiedDate) {
			this.lastModifiedDate = lastModifiedDate;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		public Folder getParentFolder() {
			return parentFolder;
		}

		public void setParentFolder(Folder parentFolder) {
			this.parentFolder = parentFolder;
		}

		public List<Folder> getSubFolders() {
			return subFolders;
		}

		public void setSubFolders(List<Folder> subFolders) {
			this.subFolders = subFolders;
		}

		public List<Long> getSharedWithUsers() {
			return sharedWithUsers;
		}

		public void setSharedWithUsers(List<Long> sharedWithUsers) {
			this.sharedWithUsers = sharedWithUsers;
		}

		public String getData() {
			return data;
		}

		public void setData(String data) {
			this.data = data;
		}


	    public List<File> getFiles() {
			return files;
		}

		public void setFiles(List<File> files) {
			this.files = files;
		}
}
