package com.cdac.project.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cdac.project.model.File;
import com.cdac.project.service.FileService;

@RestController
@RequestMapping("/api/files")
public class FileController {

	@Autowired
	private FileService fservice;
	
	@GetMapping("/")
//	public List<File> FindAllFiles(){
//		return fservice.findAllFile();
//	}
	public ResponseEntity<List<File>> FindAllFiles() {
        List<File> files = fservice.findAllFile();
        return ResponseEntity.ok(files);
    }
	
	@GetMapping("/{id}")
    public Optional<File> findFileById(@PathVariable Long id) {
        return fservice.findFileById(id);
    }

    @PostMapping("/")
    public File createFile(@RequestBody File file) {
        return fservice.saveFile(file);
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            fservice.uploadFile(file);
            return ResponseEntity.ok("File uploaded successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload file");
        }
    }

    @DeleteMapping("/{fileId}")
    public ResponseEntity<String> deleteFile(@PathVariable Long fileId) {
        try {
            fservice.deleteFileById(fileId);
            return ResponseEntity.ok("File deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete file");
        }
    }
    
    
    @PostMapping("/{fileId}/share")
    public ResponseEntity<String> shareFile(@PathVariable Long fileId, @RequestParam Long userId) {
        try {
            fservice.shareFile(fileId, userId);
            return ResponseEntity.ok("File shared successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to share file");
        }
    }

    @GetMapping("/shared")
    public ResponseEntity<List<File>> getSharedFiles(@RequestParam Long userId) {
        List<File> sharedFiles = fservice.getSharedFiles(userId);
        return ResponseEntity.ok(sharedFiles);
    }
    
    
    @GetMapping("/search")
    public ResponseEntity<List<File>> searchFiles(@RequestParam String query) {
        List<File> searchResults = fservice.searchFiles(query);
        // Assuming searchResults is sorted, you can perform binary search
        int index = binarySearch(searchResults, query);
        if (index >= 0) {
            // Found the file matching the query
            List<File> result = new ArrayList<>();
            result.add(searchResults.get(index));
            return ResponseEntity.ok(result);
        } else {
            // File not found
            return ResponseEntity.ok(Collections.emptyList());
        }
    }

    private int binarySearch(List<File> files, String query) {
        int low = 0;
        int high = files.size() - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            int cmp = files.get(mid).getName().compareTo(query);
            if (cmp == 0) {
                return mid; // Found the file
            } else if (cmp < 0) {
                low = mid + 1; // Search in the right half
            } else {
                high = mid - 1; // Search in the left half
            }
        }
        return -1; // File not found
    }
}
