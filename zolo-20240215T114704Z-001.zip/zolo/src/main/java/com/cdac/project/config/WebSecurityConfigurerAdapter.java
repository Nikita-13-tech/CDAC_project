package com.cdac.project.config;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

public class WebSecurityConfigurerAdapter {

	protected void configure(AuthenticationManagerBuilder auth) throws Exception {}

	protected void configure(HttpSecurity http) throws Exception {}

	public AuthenticationManager authenticationManagerBean() throws Exception {
		return null;
	}

}
