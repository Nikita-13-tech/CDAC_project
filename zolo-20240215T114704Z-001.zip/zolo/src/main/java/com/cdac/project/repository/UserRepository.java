package com.cdac.project.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.project.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

	
	//Custom Method to fetch record/object based on email field - non id field.
		public Optional<User> findByEmail(String email);

		public static Optional<User> findByUsername(String username) {
			// TODO Auto-generated method stub
			return null;
		}
}
